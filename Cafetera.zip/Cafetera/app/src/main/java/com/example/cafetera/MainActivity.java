package com.example.cafetera;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    Button btnLogin;
    EditText txtUderId, txtPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    public void initialize(){
        btnLogin = (Button) findViewById(R.id.btnLogin);
        txtUderId = (EditText) findViewById(R.id.txtUserId);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
    }

    public  void validate(String userId, String password){
        
        nextPage();

    }

    public void nextPage(){
        Intent i = new Intent(getApplicationContext(),Main2Activity.class);
        startActivity(i);
    }

}
